def inInit():
    print("i am init of package")