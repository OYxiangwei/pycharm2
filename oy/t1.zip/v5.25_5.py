import calendar

m = calendar.calendar(2019, l=1, c = 5)
#print(m)

#print(calendar.leapdays(2019,2039))

#print(calendar.month(2019,5))

#print(calendar.monthrange(2019,5))

#print(calendar.monthcalendar(2019,5))
#calendar.prcal(2019)
#print(calendar.prmonth(2019,5))
print(calendar.weekday(2019,5,25))