import importlib
from types import MethodType

s =importlib.import_module("01")

lei = s.student()
lei.say()

