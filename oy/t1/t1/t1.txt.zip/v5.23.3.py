import abc
class human(metaclass=abc.ABCmeta):

    @abc.abstractmethod
    @abc.abstractclassmethod
    @abc.abstractstaticmethod