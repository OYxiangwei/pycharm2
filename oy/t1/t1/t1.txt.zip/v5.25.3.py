import sys
print(sys.path)
print(type(sys.path))
for i in sys.path:
    print(i)